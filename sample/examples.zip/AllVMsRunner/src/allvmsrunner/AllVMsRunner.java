/*
 * Copyright 2015 Tomáš Šmíd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package allvmsrunner;

import cz.muni.fi.virtualtoolmanager.logicimpl.ConnectionManagerImpl;
import cz.muni.fi.virtualtoolmanager.logicimpl.VirtualMachineManagerImpl;
import cz.muni.fi.virtualtoolmanager.pubapi.entities.PhysicalMachine;
import cz.muni.fi.virtualtoolmanager.pubapi.entities.VirtualMachine;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.ConnectionFailureException;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.IncompatibleVirtToolAPIVersionException;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.UnexpectedVMStateException;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.UnknownVirtualMachineException;
import cz.muni.fi.virtualtoolmanager.pubapi.io.OutputHandler;
import cz.muni.fi.virtualtoolmanager.pubapi.managers.ConnectionManager;
import cz.muni.fi.virtualtoolmanager.pubapi.managers.VirtualMachineManager;
import cz.muni.fi.virtualtoolmanager.pubapi.managers.VirtualizationToolManager;
import cz.muni.fi.virtualtoolmanager.pubapi.types.FrontEndType;
import java.util.List;
import java.util.Scanner;

/**
 * This class demonstrates how to use API for remote virtual machine control
 * using VirtualBox.
 * In this example will be shown how to start all available virtual machines on
 * one physical machine.
 * 
 * @author Tomáš Šmíd
 */
public class AllVMsRunner {

    /**
     * This main method is meant to use command line arguments to create
     * a required physical machine with which then there will be established
     * the connection. If the connection is established successfully, then
     * all virtual machines that are available on the physical machine and are
     * registered at VirtualBox will be started.
     * At the end when the enter is pressed, all running virtual machines will
     * be shut down and physical machine disconnected.
     * 
     * @param args the command line arguments - the first one is IP address
     * of physical machine, the second one the port number of VirtualBox web
     * server, the third is the username and last one is user password
     */
    public static void main(String[] args) {
        if(args.length == 4){
            //set up the output streams
            OutputHandler.setOutputStream(System.out);
            OutputHandler.setErrorOutputStream(System.err);
            OutputHandler outputHandler = new OutputHandler();
            //set ip address, web server port, username and user password
            PhysicalMachine pm = new PhysicalMachine(args[0],args[1],args[2],args[3]);
            ConnectionManager connectionManager = new ConnectionManagerImpl();
            VirtualMachineManager vmm = new VirtualMachineManagerImpl();
            
            try{
                //connect to remote physical machine
                VirtualizationToolManager vtm = connectionManager.connectTo(pm);
                //get all available virtual machines
                List<VirtualMachine> allVMs = vtm.getVirtualMachines();

                //if there exist any virtual machines, then perform starting operation
                if(!allVMs.isEmpty()){
                    for(VirtualMachine vm : allVMs){
                        //start each virtual machine in gui
                        vmm.startVM(vm, FrontEndType.GUI);
                    }
                }
                
                Scanner in = new Scanner(System.in);
                outputHandler.printMessage("Press enter");
                in.nextLine();
                //terminate the work with virtual machines and disconnect from PM
                connectionManager.close();
            }catch(ConnectionFailureException |
                   UnexpectedVMStateException |
                   UnknownVirtualMachineException |
                   IncompatibleVirtToolAPIVersionException ex){
                //print the error message
                outputHandler.printErrorMessage(ex.getMessage());
            }
        }
    }
    
}
