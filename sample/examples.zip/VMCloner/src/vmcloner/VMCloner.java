/*
 * Copyright 2015 Tomáš Šmíd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package vmcloner;

import cz.muni.fi.virtualtoolmanager.logicimpl.ConnectionManagerImpl;
import cz.muni.fi.virtualtoolmanager.logicimpl.VirtualMachineManagerImpl;
import cz.muni.fi.virtualtoolmanager.pubapi.entities.PhysicalMachine;
import cz.muni.fi.virtualtoolmanager.pubapi.entities.PortRule;
import cz.muni.fi.virtualtoolmanager.pubapi.entities.VirtualMachine;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.ConnectionFailureException;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.IncompatibleVirtToolAPIVersionException;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.UnexpectedVMStateException;
import cz.muni.fi.virtualtoolmanager.pubapi.exceptions.UnknownVirtualMachineException;
import cz.muni.fi.virtualtoolmanager.pubapi.managers.ConnectionManager;
import cz.muni.fi.virtualtoolmanager.pubapi.managers.VirtualMachineManager;
import cz.muni.fi.virtualtoolmanager.pubapi.managers.VirtualizationToolManager;
import cz.muni.fi.virtualtoolmanager.pubapi.types.CloneType;
import cz.muni.fi.virtualtoolmanager.pubapi.types.ClosingActionType;
import cz.muni.fi.virtualtoolmanager.pubapi.types.ProtocolType;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * This class demonstrates how to use API for remote virtual machine control
 * using VirtualBox.
 * In this example will be shown how to register virtual machine. Also how to
 * clone virtual machine and how to add new port-forwarding rule.
 * 
 * @author Tomáš Šmíd
 */
public class VMCloner {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ConnectionManager connectionManager = new ConnectionManagerImpl();
        VirtualMachineManager vmm = new VirtualMachineManagerImpl();
        
        System.out.println("Enter the physical machine (each property must be "
                + "divided by space):");
        //get the physical machine properties
        String[] props = in.nextLine().split(" ");
        //create physical machine from loaded properties
        PhysicalMachine pm = new PhysicalMachine(props[0], props[1], props[2], props[3]);
        
        try{
            //connect to the physical machine, between each unsuccessful attempt
            //wait 1 second
            VirtualizationToolManager vtm = connectionManager.connectTo(pm, 1000L);
            
            //get the name of virtual machine a register it
            System.out.print("Enter the name of VM to be registered: ");
            String vmName = in.nextLine();
            vtm.registerVirtualMachine(vmName);
            
            //create a full clone of the registered virtual machine
            VirtualMachine origVM = vtm.findVirtualMachineByName(vmName);
            VirtualMachine clone = vtm.cloneVirtualMachine(origVM,
                    CloneType.FULL_FROM_MACHINE_STATE);
            
            //add new port-forwarding rule to the virtual machine clone
            System.out.println("Enter the port rule (ruleName, protocol, hostPort, "
                    + "hostIP, guestPort, guestIP - each property must be "
                    + "divided by space):");
            String[] att = in.nextLine().split(" ");
            PortRule pr = getPortRule(att);
            vmm.addPortRule(clone, pr);
            
            //disconnect from physical machine, no final actions
            connectionManager.disconnectFrom(pm, ClosingActionType.NONE);
        }catch(ConnectionFailureException |
                UnexpectedVMStateException |
                UnknownVirtualMachineException |
                IncompatibleVirtToolAPIVersionException ex){
                    //print the error message
                    System.err.println(ex.getMessage());
            }
        
    }
    
    private static PortRule getPortRule(String[] att){
        String ruleName = att[0];
        ProtocolType protocol = (att[1].toLowerCase().equals("tcp") ?
                                ProtocolType.TCP : ProtocolType.UDP);
        int hostPort = Integer.valueOf(att[2]);
        String hostIP = att[3];
        int guestPort = Integer.valueOf(att[4]);
        String guestIP = att[5];
        
        return new PortRule.Builder(ruleName, hostPort, guestPort)
                                .protocol(protocol).hostIP(hostIP)
                                .guestIP(guestIP).build();
    }
    
}
